// TODO: implement Message.js
