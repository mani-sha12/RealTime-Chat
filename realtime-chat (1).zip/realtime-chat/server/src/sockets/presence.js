// TODO: implement presence.js
